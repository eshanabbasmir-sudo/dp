#!/usr/bin/env bash
# PRIMEPOOL — Supporter VPS agent installer (self-contained).
# The agent source is embedded inline — no download needed.
#
# Usage:
#   export MAIN_URL="https://your-main-url"
#   export REGISTRATION_TOKEN="<your-token>"
#   curl -fsSL https://your-main-url/scripts/install-agent.sh | bash
#
# Or for production with systemd (requires root):
#   sudo MAIN_URL=... REGISTRATION_TOKEN=... bash install-agent.sh

set -euo pipefail

YELLOW='\033[1;33m'; GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[primepool]${NC} $*"; }
warn() { echo -e "${YELLOW}[warn]${NC} $*"; }
err()  { echo -e "${RED}[error]${NC} $*" >&2; }

# ─── Validate env ───────────────────────────────────────────────────────────
MAIN_URL="${MAIN_URL:-}"
REGISTRATION_TOKEN="${REGISTRATION_TOKEN:-}"

if [[ -z "$MAIN_URL" ]]; then err "MAIN_URL env var required"; exit 1; fi
if [[ -z "$REGISTRATION_TOKEN" ]]; then err "REGISTRATION_TOKEN env var required"; exit 1; fi

MAIN_URL="${MAIN_URL%/}"  # strip trailing slash
HEARTBEAT_INTERVAL="${HEARTBEAT_INTERVAL:-10000}"
POLL_INTERVAL="${POLL_INTERVAL:-5000}"

log "PRIMEPOOL worker agent installer"
log "Main URL: $MAIN_URL"
log "Token: ${REGISTRATION_TOKEN:0:16}..."
echo ""

# ─── Step 1: Install Node.js 20+ if missing ────────────────────────────────
if ! command -v node >/dev/null 2>&1; then
  log "Installing Node.js 20 LTS..."
  if command -v apt-get >/dev/null 2>&1; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
    apt-get install -y nodejs >/dev/null 2>&1
  elif command -v yum >/dev/null 2>&1; then
    curl -fsSL https://rpm.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
    yum install -y nodejs >/dev/null 2>&1
  else
    err "Could not detect package manager. Please install Node.js 20+ manually."
    exit 1
  fi
fi
log "Node.js: $(node -v)"

# ─── Step 2: Create agent directory ─────────────────────────────────────────
INSTALL_DIR="${AGENT_DIR:-/opt/primepool-agent}"
[[ "$EUID" -eq 0 ]] || INSTALL_DIR="${AGENT_DIR:-$HOME/primepool-agent}"
mkdir -p "$INSTALL_DIR/data"
cd "$INSTALL_DIR"
log "Install dir: $INSTALL_DIR"

# ─── Step 3: Write agent source (embedded, no download) ─────────────────────
log "Writing agent source..."
cat > "$INSTALL_DIR/agent.js" <<'PRIMEPOOL_AGENT_EOF'
import { spawn, execFile } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { homedir, hostname, platform, arch, release } from "node:os";
import { join } from "node:path";
import { env, exit } from "node:process";
const process = globalThis.process;

const MAIN_URL = (env.MAIN_URL || "").replace(/\/+$/, "");
const REGISTRATION_TOKEN = env.REGISTRATION_TOKEN || "";
const HEARTBEAT_INTERVAL = Number(env.HEARTBEAT_INTERVAL || 10000);
const POLL_INTERVAL = Number(env.POLL_INTERVAL || 5000);
const STATE_PATH = env.PRIMEPOOL_AGENT_CONFIG || join(homedir(), ".primepool", "agent.json");
const DATA_DIR = env.AGENT_DATA_DIR || join(homedir(), ".primepool", "data");

function save(cfg) { try { mkdirSync(join(STATE_PATH, ".."), { recursive: true }); writeFileSync(STATE_PATH, JSON.stringify(cfg, null, 2), { mode: 0o600 }); } catch {} }
function loadCfg() { try { return JSON.parse(readFileSync(STATE_PATH, "utf8")); } catch { return {}; } }

function readMem() {
  try {
    const t = readFileSync("/proc/meminfo", "utf8");
    const m = {};
    t.split("\n").forEach(l => { const x = l.match(/^(\w+):\s+(\d+)/); if (x) m[x[1]] = Number(x[2]) * 1024; });
    return { total: m.MemTotal || 0, available: m.MemAvailable || m.MemFree || 0, free: m.MemFree || 0, cached: m.Cached || 0, used: (m.MemTotal || 0) - (m.MemAvailable || 0) };
  } catch { return { total: 0, available: 0, free: 0, cached: 0, used: 0 }; }
}

function readLoad() {
  try { const p = readFileSync("/proc/loadavg", "utf8").trim().split(/\s+/); return { avg1: Number(p[0]) || 0, avg5: Number(p[1]) || 0, avg15: Number(p[2]) || 0 }; }
  catch { return { avg1: 0, avg5: 0, avg15: 0 }; }
}

let prevCpu = null;
function readCpu() {
  try {
    const p = readFileSync("/proc/stat", "utf8").split("\n")[0].split(/\s+/).slice(1).map(Number);
    const idle = p[3] || 0, total = p.reduce((a, b) => a + b, 0);
    if (!prevCpu) { prevCpu = { idle, total }; return 0; }
    const dT = total - prevCpu.total, dI = idle - prevCpu.idle;
    prevCpu = { idle, total };
    return dT > 0 ? Math.max(0, Math.min(100, (1 - dI / dT) * 100)) : 0;
  } catch { return 0; }
}

function readCpuInfo() {
  try { const t = readFileSync("/proc/cpuinfo", "utf8"); return { cores: (t.match(/^processor\s*:/gm) || []).length || 1 }; }
  catch { return { cores: 1 }; }
}

function readDisk() {
  return new Promise(r => {
    execFile("df", ["-B1", "--output=source,size,used,avail", "/"], { timeout: 2000 }, (e, o) => {
      if (e || !o) return r({ filesystem: "", total: 0, used: 0, available: 0 });
      const c = o.trim().split("\n")[1]?.trim().split(/\s+/) || [];
      r({ filesystem: c[0] || "", total: Number(c[1]) || 0, used: Number(c[2]) || 0, available: Number(c[3]) || 0 });
    });
  });
}

function readNet() {
  try {
    const t = readFileSync("/proc/net/dev", "utf8").split("\n").slice(2);
    let rx = 0, tx = 0, iface = "lo";
    for (const l of t) {
      const p = l.split(":");
      if (p.length < 2) continue;
      const n = p[0].trim();
      if (n === "lo") continue;
      const f = p[1].trim().split(/\s+/).map(Number);
      rx += f[0] || 0; tx += f[8] || 0; iface = n;
    }
    return { rx, tx, interface: iface };
  } catch { return { rx: 0, tx: 0, interface: "" }; }
}

function readUptime() {
  try { return Math.floor(Number(readFileSync("/proc/uptime", "utf8").split(" ")[0]) || 0); }
  catch { return 0; }
}

async function http(url, init = {}) {
  const h = { "content-type": "application/json", ...(init.headers || {}) };
  const r = await fetch(url, { ...init, headers: h, body: init.body ? JSON.stringify(init.body) : undefined, signal: AbortSignal.timeout(30000) });
  const t = await r.text();
  let j; try { j = t ? JSON.parse(t) : {}; } catch { j = { raw: t }; }
  if (!r.ok) throw new Error(`HTTP ${r.status}: ${j.error || t}`);
  return j;
}

async function register(cfg) {
  if (!MAIN_URL || !REGISTRATION_TOKEN) { console.error("MAIN_URL and REGISTRATION_TOKEN required"); return false; }
  const mem = readMem(), cpu = readCpuInfo(), disk = await readDisk();
  try {
    const res = await http(`${MAIN_URL}/api/nodes/register`, {
      method: "POST",
      body: {
        registrationToken: REGISTRATION_TOKEN, hostname: hostname(), architecture: arch(), os: platform(), kernel: release(),
        cpuCores: cpu.cores, ramBytes: mem.total, diskBytes: disk.total, containerRuntime: "process", features: [], displayName: hostname()
      }
    });
    if (!res.ok) { console.error("registration failed:", res); return false; }
    cfg.nodeId = res.nodeId; cfg.nodeToken = res.agentToken; cfg.mainUrl = MAIN_URL;
    save(cfg);
    console.log(`[agent] registered as ${cfg.nodeId} (CPU=${cpu.cores} RAM=${(mem.total / 1073741824).toFixed(1)}GB disk=${(disk.total / 1073741824).toFixed(1)}GB)`);
    return true;
  } catch (e) { console.error("[agent] registration error:", e.message); return false; }
}

async function heartbeat(cfg) {
  if (!cfg.nodeId || !cfg.nodeToken) return false;
  const mem = readMem(), load = readLoad(), cpu = readCpu(), disk = await readDisk(), net = readNet(), up = readUptime();
  try {
    await http(`${MAIN_URL}/api/nodes/heartbeat`, {
      method: "POST",
      headers: { authorization: `Bearer ${cfg.nodeToken}`, "x-primepool-node": cfg.nodeId },
      body: {
        status: "online", cpu_usage: cpu, ram_used: mem.used, ram_total: mem.total, ram_available: mem.available, ram_cached: mem.cached,
        disk_free: disk.available, disk_total: disk.total, disk_used: disk.used, filesystem: disk.filesystem, mount_point: "/",
        load_avg1: load.avg1, load_avg5: load.avg5, load_avg15: load.avg15, net_rx: net.rx, net_tx: net.tx, net_interface: net.interface,
        uptime: up, timestamp: Date.now()
      }
    });
    return true;
  } catch (e) { console.warn(`[agent] heartbeat failed: ${e.message}`); return false; }
}

const running = new Map();

async function startWorkload(cfg, p) {
  const wd = join(DATA_DIR, p.workloadId);
  try { mkdirSync(wd, { recursive: true }); } catch {}
  const cmd = p.command || "sleep infinity";
  const child = spawn("/bin/sh", ["-c", cmd], {
    stdio: ["pipe", "pipe", "pipe"], cwd: wd,
    env: { PATH: env.PATH || "/usr/local/bin:/usr/bin:/bin", HOME: env.HOME || "/tmp", TERM: "xterm-256color", PRIMEPOOL_WORKSPACE: p.workloadId, PRIMEPOOL_MAIN: MAIN_URL }
  });
  child.stdout?.on("data", () => {}); child.stderr?.on("data", () => {});
  child.on("exit", (code) => { console.log(`[agent] workload ${p.workloadId} exited (${code})`); running.delete(p.workloadId); report(cfg, p.workloadId, "stopped", {}).catch(() => {}); });
  child.on("error", (e) => { console.error(`[agent] workload ${p.workloadId} error: ${e.message}`); });
  running.set(p.workloadId, { pid: child.pid, child });
  console.log(`[agent] workload ${p.workloadId} started (pid=${child.pid}, cmd=${cmd})`);
  await report(cfg, p.workloadId, "running", { pid: child.pid });
}

async function stopWorkload(cfg, p) {
  const w = running.get(p.workloadId);
  if (w?.child) { try { w.child.kill("SIGTERM"); } catch {} setTimeout(() => { try { w.child.kill("SIGKILL"); } catch {} }, 2000); }
  running.delete(p.workloadId);
  await report(cfg, p.workloadId, "stopped", {});
}

async function report(cfg, wid, status, payload) {
  try { await http(`${MAIN_URL}/api/workloads/${wid}/status`, { method: "POST", headers: { authorization: `Bearer ${cfg.nodeToken}`, "x-primepool-node": cfg.nodeId }, body: { status, ...payload } }); }
  catch (e) { console.warn(`[agent] report failed: ${e.message}`); }
}

async function poll(cfg) {
  if (!cfg.nodeId || !cfg.nodeToken) return;
  try {
    const res = await http(`${MAIN_URL}/api/agent/instructions`, { method: "GET", headers: { authorization: `Bearer ${cfg.nodeToken}`, "x-primepool-node": cfg.nodeId } });
    if (!res.instructions) return;
    for (const instr of res.instructions) {
      const p = instr.payload || {};
      console.log(`[agent] instruction: ${instr.type} (workload=${p.workloadId || "—"})`);
      try {
        if (instr.type === "start_workload") await startWorkload(cfg, p);
        else if (instr.type === "stop_workload" || instr.type === "delete_workload") await stopWorkload(cfg, p);
      } catch (e) { console.error(`[agent] instruction ${instr.type} failed:`, e.message); }
    }
  } catch (e) { if (!String(e.message).includes("HTTP 401")) console.warn(`[agent] poll error: ${e.message}`); }
}

async function main() {
  console.log("======================================");
  console.log(" PRIMEPOOL worker agent v1.0.0");
  console.log("======================================");
  console.log(`[agent] main_url = ${MAIN_URL || "(not set)"}`);
  let cfg = loadCfg();
  if (!cfg.nodeId || !cfg.nodeToken || cfg.mainUrl !== MAIN_URL) {
    if (!await register(cfg)) { console.error("[agent] registration failed. Exiting."); exit(1); }
  } else {
    console.log(`[agent] node_id = ${cfg.nodeId}`);
  }
  console.log(`[agent] data_dir = ${DATA_DIR}`);
  try { mkdirSync(DATA_DIR, { recursive: true }); } catch {}
  console.log(`[agent] running. Heartbeat every ${HEARTBEAT_INTERVAL}ms. Polling every ${POLL_INTERVAL}ms.`);
  await heartbeat(cfg);
  let hbFail = 0;
  setInterval(async () => { try { if (await heartbeat(cfg)) hbFail = 0; else { hbFail++; if (hbFail > 30) { console.warn("[agent] sustained failure — re-registering"); if (await register(cfg)) hbFail = 0; } } } catch (e) { console.warn(`[agent] hb: ${e.message}`); } }, HEARTBEAT_INTERVAL);
  setInterval(async () => { try { await poll(cfg); } catch (e) { console.warn(`[agent] poll: ${e.message}`); } }, POLL_INTERVAL);
  setInterval(() => {}, 1 << 30);
  process.on("uncaughtException", (e) => console.error("[agent] uncaught:", e));
  process.on("unhandledRejection", (e) => console.error("[agent] unhandled:", e));
}

main().catch((e) => { console.error("[agent] fatal:", e); exit(1); });
PRIMEPOOL_AGENT_EOF

log "Agent source written ($INSTALL_DIR/agent.js)"

# ─── Step 4: Write env file ──────────────────────────────────────────────────
ENV_FILE="$INSTALL_DIR/.env"
cat > "$ENV_FILE" <<EOF
MAIN_URL=$MAIN_URL
REGISTRATION_TOKEN=$REGISTRATION_TOKEN
HEARTBEAT_INTERVAL=$HEARTBEAT_INTERVAL
POLL_INTERVAL=$POLL_INTERVAL
AGENT_DATA_DIR=$INSTALL_DIR/data
PRIMEPOOL_AGENT_CONFIG=$INSTALL_DIR/agent.json
EOF
chmod 600 "$ENV_FILE"
log "Env file written ($ENV_FILE)"

# ─── Step 5: Run ────────────────────────────────────────────────────────────
echo ""
log "Starting agent..."
log "(Press Ctrl+C to stop. For production, run under systemd — see below.)"
echo ""

# Prefer systemd when it's actually usable (root + systemd present + pid 1
# is actually systemd — many containers have systemctl installed but no
# running systemd, which silently breaks service installs).
USE_SYSTEMD=0
if [[ "$EUID" -eq 0 ]] && command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  USE_SYSTEMD=1
fi

if [[ "$USE_SYSTEMD" -eq 1 ]]; then
  SERVICE_USER="${SERVICE_USER:-primepool-agent}"
  if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
    useradd --system --create-home --shell /bin/bash "$SERVICE_USER" 2>/dev/null || true
  fi
  chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"

  cat > /etc/systemd/system/primepool-agent.service <<EOF
[Unit]
Description=PRIMEPOOL Worker Agent
After=network.target
Wants=network.target

[Service]
Type=simple
User=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$(command -v node) $INSTALL_DIR/agent.js
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable primepool-agent
  systemctl restart primepool-agent
  sleep 3

  if systemctl is-active --quiet primepool-agent; then
    log "Agent installed as a systemd service ✓"
    log "Check logs: journalctl -u primepool-agent -f"
    log "Status:     systemctl status primepool-agent"
  else
    err "Agent failed to start. Logs:"
    journalctl -u primepool-agent --no-pager -n 30
    exit 1
  fi
else
  # No usable systemd (plain container, rootless host, minimal VPS, WSL, etc).
  # Run as a detached background daemon that survives the shell closing,
  # wrapped in a tiny watchdog loop so it self-heals if the agent process
  # ever dies — this is what makes the one-line install "set and forget"
  # even with no init system available at all.
  LOG_FILE="$INSTALL_DIR/agent.log"
  WATCHDOG="$INSTALL_DIR/watchdog.sh"
  PID_FILE="$INSTALL_DIR/agent.pid"

  cat > "$WATCHDOG" <<EOF
#!/usr/bin/env bash
cd "$INSTALL_DIR"
set -a; source "$ENV_FILE"; set +a
while true; do
  node "$INSTALL_DIR/agent.js" >> "$LOG_FILE" 2>&1
  echo "[watchdog] agent exited, restarting in 5s..." >> "$LOG_FILE"
  sleep 5
done
EOF
  chmod +x "$WATCHDOG"

  # Kill any previous instance of this installer's watchdog before relaunching
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    sleep 1
  fi

  nohup "$WATCHDOG" >> "$LOG_FILE" 2>&1 &
  echo $! > "$PID_FILE"
  disown

  sleep 2
  if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    log "Agent is running in the background ✓ (pid $(cat "$PID_FILE"))"
    log "Logs:   tail -f $LOG_FILE"
    log "Stop:   kill \$(cat $PID_FILE)"

    # Best-effort: auto-start on reboot via cron @reboot if cron is available
    # and this user can edit their own crontab (harmless if it isn't).
    if command -v crontab >/dev/null 2>&1; then
      ( crontab -l 2>/dev/null | grep -v "$WATCHDOG" ; echo "@reboot nohup $WATCHDOG >> $LOG_FILE 2>&1 &" ) | crontab - 2>/dev/null || true
    fi
  else
    err "Agent failed to start. Last log lines:"
    tail -n 30 "$LOG_FILE" 2>/dev/null || true
    exit 1
  fi
fi
