#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════════
#  PrimePool — one-shot installer
#  by PrimeTech · support: primetech3310@prme.com
#
#  Run this from inside the PrimePool project folder:
#     bash install.sh
#
#  It will:
#    1. Install Node.js 20+, build tools, and any other required packages
#    2. Install project dependencies
#    3. Ask which port you want to host PrimePool on
#    4. Generate a secure .env (random JWT secret, your chosen port)
#    5. Set up the database (Prisma / SQLite, no manual steps needed)
#    6. Build the production app
#    7. Start it — as a systemd service when possible, otherwise as a
#       self-restarting background process — and print the URL to open
# ════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# ─── Pretty output ───────────────────────────────────────────────────────────
BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
log()   { echo -e "${GREEN}[primepool]${NC} $*"; }
warn()  { echo -e "${YELLOW}[warn]${NC} $*"; }
err()   { echo -e "${RED}[error]${NC} $*" >&2; }
title() { echo -e "\n${BOLD}${CYAN}── $* ──${NC}\n"; }

trap 'err "Install failed on line $LINENO. See the message above for details."' ERR

# ─── Must be run from the project directory ─────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [[ ! -f "package.json" ]] || ! grep -q '"primepool"' package.json 2>/dev/null; then
  err "this doesn't look like the PrimePool project folder (no matching package.json found)."
  err "cd into the folder containing install.sh and the PrimePool source, then re-run."
  exit 1
fi

IS_ROOT=0
[[ "$EUID" -eq 0 ]] && IS_ROOT=1
SUDO=""
if [[ "$IS_ROOT" -eq 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    SUDO="sudo"
  else
    warn "not running as root and no sudo available — package installation may fail."
    warn "if steps below fail, re-run with: sudo bash install.sh"
  fi
fi

echo ""
echo -e "${BOLD}${CYAN}"
cat <<'BANNER'
 ____       _               ____             _
|  _ \ _ __(_)_ __ ___   ___|  _ \ ___   ___ | |
| |_) | '__| | '_ ` _ \ / _ \ |_) / _ \ / _ \| |
|  __/| |  | | | | | | |  __/  __/ (_) | (_) | |
|_|   |_|  |_|_| |_| |_|\___|_|   \___/ \___/|_|

BANNER
echo -e "${NC}"
log "PrimePool installer — by PrimeTech"
log "This installs everything needed and gets your pool running."
echo ""

# ─── 1. System packages ──────────────────────────────────────────────────────
title "Step 1/7 — Checking system packages"

OS="$(uname -s)"
PKG_MANAGER=""
if [[ "$OS" == "Linux" ]]; then
  if command -v apt-get >/dev/null 2>&1; then PKG_MANAGER="apt"
  elif command -v dnf >/dev/null 2>&1; then PKG_MANAGER="dnf"
  elif command -v yum >/dev/null 2>&1; then PKG_MANAGER="yum"
  elif command -v apk >/dev/null 2>&1; then PKG_MANAGER="apk"
  elif command -v pacman >/dev/null 2>&1; then PKG_MANAGER="pacman"
  fi
fi

install_pkgs() {
  # $@ = package names (apt/dnf/yum/pacman naming; apk list passed separately below)
  case "$PKG_MANAGER" in
    apt)
      $SUDO apt-get update -qq
      $SUDO apt-get install -y -qq "$@" >/dev/null
      ;;
    dnf) $SUDO dnf install -y -q "$@" >/dev/null ;;
    yum) $SUDO yum install -y -q "$@" >/dev/null ;;
    pacman) $SUDO pacman -Sy --noconfirm --needed "$@" >/dev/null ;;
    apk) $SUDO apk add --no-cache "$@" >/dev/null ;;
    *) warn "unrecognized package manager — skipping system package install for: $*" ;;
  esac
}

if [[ -n "$PKG_MANAGER" ]]; then
  log "detected package manager: $PKG_MANAGER"
  log "installing base packages (curl, git, build tools, openssl)..."
  case "$PKG_MANAGER" in
    apt)     install_pkgs curl ca-certificates gnupg git build-essential openssl lsof ;;
    dnf|yum) install_pkgs curl ca-certificates gnupg2 git gcc gcc-c++ make openssl lsof ;;
    pacman)  install_pkgs curl ca-certificates gnupg git base-devel openssl lsof ;;
    apk)     install_pkgs curl ca-certificates gnupg git build-base openssl lsof bash ;;
  esac
else
  warn "could not detect a supported package manager (apt/dnf/yum/pacman/apk)."
  warn "make sure curl, git, build tools and openssl are already installed, then continue."
fi

# Node.js 20+ LTS
NEED_NODE=1
if command -v node >/dev/null 2>&1; then
  NODE_MAJOR="$(node -v | sed 's/^v//' | cut -d. -f1)"
  if [[ "$NODE_MAJOR" -ge 20 ]]; then NEED_NODE=0; fi
fi
if [[ "$NEED_NODE" -eq 1 ]]; then
  log "installing Node.js 20 LTS..."
  case "$PKG_MANAGER" in
    apt)
      curl -fsSL https://deb.nodesource.com/setup_20.x | $SUDO bash - >/dev/null 2>&1
      $SUDO apt-get install -y -qq nodejs >/dev/null
      ;;
    dnf|yum)
      curl -fsSL https://rpm.nodesource.com/setup_20.x | $SUDO bash - >/dev/null 2>&1
      install_pkgs nodejs
      ;;
    pacman) install_pkgs nodejs npm ;;
    apk)    install_pkgs nodejs npm ;;
    *)
      err "cannot auto-install Node.js on this system. Install Node.js 20+ manually and re-run."
      exit 1
      ;;
  esac
else
  log "Node.js already installed: $(node -v)"
fi
log "node: $(node -v)   npm: $(npm -v)"

# ─── 2. Project dependencies ─────────────────────────────────────────────────
title "Step 2/7 — Installing project dependencies"
log "this can take a minute..."
if command -v bun >/dev/null 2>&1; then
  bun install
else
  npm install --no-audit --no-fund
fi
log "dependencies installed ✓"

# ─── 3. Ask which port to host on ────────────────────────────────────────────
title "Step 3/7 — Choose a port"

port_in_use() {
  local p="$1"
  if command -v lsof >/dev/null 2>&1; then
    lsof -i ":$p" -sTCP:LISTEN >/dev/null 2>&1
  elif command -v ss >/dev/null 2>&1; then
    ss -ltn 2>/dev/null | awk '{print $4}' | grep -q ":$p\$"
  else
    return 1 # can't check — assume free
  fi
}

DEFAULT_PORT=3000
CHOSEN_PORT=""

# Allow non-interactive use: PRIMEPOOL_PORT=8080 bash install.sh
if [[ -n "${PRIMEPOOL_PORT:-}" ]]; then
  CHOSEN_PORT="$PRIMEPOOL_PORT"
  log "using port from PRIMEPOOL_PORT: $CHOSEN_PORT"
elif [[ -t 0 ]]; then
  while true; do
    read -rp "$(echo -e "${BOLD}Which port do you want to host PrimePool on?${NC} [default: $DEFAULT_PORT]: ")" INPUT_PORT
    PORT_TO_CHECK="${INPUT_PORT:-$DEFAULT_PORT}"
    if ! [[ "$PORT_TO_CHECK" =~ ^[0-9]+$ ]] || (( PORT_TO_CHECK < 1 || PORT_TO_CHECK > 65535 )); then
      err "'$PORT_TO_CHECK' isn't a valid port number (1-65535). Try again."
      continue
    fi
    if port_in_use "$PORT_TO_CHECK"; then
      warn "port $PORT_TO_CHECK looks like it's already in use."
      read -rp "Use it anyway? [y/N]: " CONFIRM
      [[ "$CONFIRM" =~ ^[Yy]$ ]] || continue
    fi
    CHOSEN_PORT="$PORT_TO_CHECK"
    break
  done
else
  warn "no interactive terminal detected — defaulting to port $DEFAULT_PORT"
  warn "(set PRIMEPOOL_PORT=xxxx before running install.sh to choose one non-interactively)"
  CHOSEN_PORT="$DEFAULT_PORT"
fi

log "PrimePool will be hosted on port $CHOSEN_PORT"

# ─── 4. Write .env ────────────────────────────────────────────────────────────
title "Step 4/7 — Configuring environment"

mkdir -p db

if [[ -f ".env" ]]; then
  log ".env already exists — updating PORT and keeping your other settings."
  if grep -q '^PORT=' .env; then
    sed -i.bak "s|^PORT=.*|PORT=$CHOSEN_PORT|" .env && rm -f .env.bak
  else
    echo "PORT=$CHOSEN_PORT" >> .env
  fi
  if ! grep -q '^DATABASE_URL=' .env; then
    echo "DATABASE_URL=\"file:./db/primepool.db\"" >> .env
  fi
  if ! grep -q '^JWT_SECRET=' .env || grep -q 'CHANGE_ME' .env; then
    JWT_SECRET="$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | base64)"
    if grep -q '^JWT_SECRET=' .env; then
      sed -i.bak "s|^JWT_SECRET=.*|JWT_SECRET=\"$JWT_SECRET\"|" .env && rm -f .env.bak
    else
      echo "JWT_SECRET=\"$JWT_SECRET\"" >> .env
    fi
  fi
else
  log "creating .env from .env.example..."
  cp .env.example .env
  JWT_SECRET="$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | base64)"
  sed -i.bak "s|^JWT_SECRET=.*|JWT_SECRET=\"$JWT_SECRET\"|" .env && rm -f .env.bak
  sed -i.bak "s|^PORT=.*|PORT=$CHOSEN_PORT|" .env && rm -f .env.bak
  sed -i.bak "s|^NODE_ENV=.*|NODE_ENV=production|" .env && rm -f .env.bak
fi

# Try to detect a usable public URL (best-effort, never fails the install)
PUBLIC_IP="$(curl -fsSL --max-time 3 https://ifconfig.me 2>/dev/null || true)"
if [[ -n "$PUBLIC_IP" ]]; then
  if grep -q '^PUBLIC_URL=' .env; then
    sed -i.bak "s|^PUBLIC_URL=.*|PUBLIC_URL=\"http://$PUBLIC_IP:$CHOSEN_PORT\"|" .env && rm -f .env.bak
  else
    echo "PUBLIC_URL=\"http://$PUBLIC_IP:$CHOSEN_PORT\"" >> .env
  fi
  log "detected public IP: $PUBLIC_IP"
else
  warn "could not auto-detect a public IP — PUBLIC_URL left as localhost. Edit .env if needed."
fi

log ".env configured ✓"

# ─── 5. Database ──────────────────────────────────────────────────────────────
title "Step 5/7 — Setting up the database"
set -a; source .env; set +a
if command -v bunx >/dev/null 2>&1; then
  bunx prisma generate
  bunx prisma db push --accept-data-loss
else
  npx --yes prisma generate
  npx --yes prisma db push --accept-data-loss
fi
log "database ready ✓"

# ─── 6. Build ─────────────────────────────────────────────────────────────────
title "Step 6/7 — Building PrimePool (production build)"
if command -v bun >/dev/null 2>&1; then
  bun run build
else
  npm run build
fi
log "build complete ✓"

# ─── 7. Start ─────────────────────────────────────────────────────────────────
title "Step 7/7 — Starting PrimePool"

USE_SYSTEMD=0
if [[ "$IS_ROOT" -eq 1 ]] && command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  USE_SYSTEMD=1
fi

NODE_BIN="$(command -v node)"
APP_DIR="$SCRIPT_DIR"
START_CMD="$NODE_BIN .next/standalone/server.js"
if [[ ! -f "$APP_DIR/.next/standalone/server.js" ]]; then
  # Fallback for setups without `output: standalone` in next.config
  START_CMD="$(command -v npx) next start -p $CHOSEN_PORT"
fi

if [[ "$USE_SYSTEMD" -eq 1 ]]; then
  log "installing systemd service 'primepool'..."
  cat > /etc/systemd/system/primepool.service <<EOF
[Unit]
Description=PrimePool Control Plane
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
Environment=PORT=$CHOSEN_PORT
ExecStart=$START_CMD
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable primepool >/dev/null
  systemctl restart primepool
  sleep 3
  if systemctl is-active --quiet primepool; then
    log "PrimePool is running as a systemd service ✓"
    log "Manage it with: systemctl [start|stop|restart|status] primepool"
    log "Logs:            journalctl -u primepool -f"
  else
    err "PrimePool failed to start. Recent logs:"
    journalctl -u primepool --no-pager -n 40
    exit 1
  fi
else
  warn "no systemd available (or not running as root) — starting as a background process instead."
  LOG_FILE="$APP_DIR/primepool.log"
  PID_FILE="$APP_DIR/primepool.pid"
  WATCHDOG="$APP_DIR/primepool-watchdog.sh"

  cat > "$WATCHDOG" <<EOF
#!/usr/bin/env bash
cd "$APP_DIR"
set -a; source "$APP_DIR/.env"; set +a
export PORT=$CHOSEN_PORT
while true; do
  $START_CMD >> "$LOG_FILE" 2>&1
  echo "[watchdog] primepool exited, restarting in 5s..." >> "$LOG_FILE"
  sleep 5
done
EOF
  chmod +x "$WATCHDOG"

  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    sleep 1
  fi

  nohup "$WATCHDOG" >> "$LOG_FILE" 2>&1 &
  echo $! > "$PID_FILE"
  disown
  sleep 3

  if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    log "PrimePool is running in the background ✓ (pid $(cat "$PID_FILE"))"
    log "Logs:   tail -f $LOG_FILE"
    log "Stop:   kill \$(cat $PID_FILE)"
    if command -v crontab >/dev/null 2>&1; then
      ( crontab -l 2>/dev/null | grep -v "$WATCHDOG" ; echo "@reboot nohup $WATCHDOG >> $LOG_FILE 2>&1 &" ) | crontab - 2>/dev/null || true
    fi
  else
    err "PrimePool failed to start. Recent logs:"
    tail -n 40 "$LOG_FILE" 2>/dev/null || true
    exit 1
  fi
fi

# ─── Done ──────────────────────────────────────────────────────────────────
PUBLIC_URL_LINE="$(grep '^PUBLIC_URL=' .env | cut -d= -f2- | tr -d '"')"
echo ""
log "════════════════════════════════════════════════════════════════════"
log " PrimePool is up and running!"
log "════════════════════════════════════════════════════════════════════"
echo ""
log "Open it at:"
log "  → http://localhost:$CHOSEN_PORT"
[[ -n "$PUBLIC_URL_LINE" ]] && log "  → $PUBLIC_URL_LINE"
echo ""
log "First visit will walk you through creating your admin account —"
log "there's no default password to remember or change."
echo ""
log "To add a supporter machine to your pool afterwards: open Nodes →"
log "'Add Worker' in the dashboard and paste the one-line command it gives you."
echo ""
log "Support: primetech3310@prme.com"
echo ""
