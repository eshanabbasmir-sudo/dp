"use client";

import { useEffect, useState } from "react";
import { fetchApi } from "@/lib/fetch-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Eye, EyeOff, Lock, Mail, Shield, User, ArrowRight, Loader2 } from "lucide-react";

export function LoginScreen({ onLogged }: { onLogged: () => void }) {
  const [checking, setChecking] = useState(true);
  const [needsBootstrap, setNeedsBootstrap] = useState(false);

  useEffect(() => {
    fetchApi("/api/auth/bootstrap").then((res) => {
      setNeedsBootstrap(!!res.needsBootstrap);
      setChecking(false);
    }).catch(() => setChecking(false));
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div
          className="absolute -top-1/3 left-1/2 -translate-x-1/2 w-[900px] h-[900px] rounded-full opacity-[0.16] blur-3xl"
          style={{ background: "radial-gradient(circle, var(--violet), transparent 60%)" }}
        />
        <div
          className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full opacity-[0.10] blur-3xl"
          style={{ background: "radial-gradient(circle, var(--cyan), transparent 60%)" }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.035)_1px,transparent_0)] [background-size:28px_28px]" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <PrimePoolLogo className="w-14 h-14 mb-4" />
          <h1 className="text-3xl font-semibold tracking-tight">PrimePool</h1>
          <p className="text-sm text-muted-foreground mt-1.5 text-center max-w-xs">
            One control plane. Multiple machines. One resource pool.
          </p>
        </div>

        {checking ? (
          <Card className="p-10 bg-card/80 backdrop-blur-sm border-border/60 flex items-center justify-center">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          </Card>
        ) : needsBootstrap ? (
          <SetupForm onDone={onLogged} />
        ) : (
          <LoginForm onLogged={onLogged} />
        )}

        <p className="text-center text-xs text-muted-foreground/60 mt-6">
          PrimePool · Distributed VPS Resource Pool · by PrimeTech
        </p>
      </div>
    </div>
  );
}

function LoginForm({ onLogged }: { onLogged: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [needsTotp, setNeedsTotp] = useState(false);
  const [totpCode, setTotpCode] = useState("");

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (busy) return;
    if (!email.trim() || !password) {
      toast.error("Please enter both email and password");
      return;
    }
    if (needsTotp && !totpCode.trim()) {
      toast.error("Enter your 6-digit authentication code");
      return;
    }
    setBusy(true);
    try {
      const res = await fetchApi("/api/auth/login", {
        method: "POST",
        body: { email: email.trim().toLowerCase(), password, totpCode: needsTotp ? totpCode.trim() : undefined },
      });
      if (res.requiresTotp) {
        setNeedsTotp(true);
      } else if (res.ok) {
        toast.success("Welcome back");
        onLogged();
      } else {
        toast.error(res.error || "Invalid email or password");
      }
    } catch (e: any) {
      toast.error(e?.message || "Login failed — please try again");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="p-7 bg-card/80 backdrop-blur-sm border-border/60 shadow-2xl shadow-black/20">
      <form onSubmit={submit} className="space-y-4">
        {!needsTotp ? (
          <>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-xs text-muted-foreground">
                Email
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  autoFocus
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  className="pl-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-xs text-muted-foreground">
                Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={show ? "text" : "password"}
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pl-9 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  tabIndex={-1}
                >
                  {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="space-y-2">
            <Label htmlFor="totp" className="text-xs text-muted-foreground">
              Authentication code
            </Label>
            <div className="relative">
              <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="totp"
                inputMode="numeric"
                autoFocus
                required
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value.replace(/\s/g, ""))}
                placeholder="6-digit code or recovery code"
                className="pl-9"
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Enter the code from your authenticator app, or a recovery code if you've lost access.
            </p>
          </div>
        )}
        <Button type="submit" disabled={busy} className="w-full bg-violet hover:bg-violet/90 gap-1.5">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <>{needsTotp ? "Verify" : "Sign in"} <ArrowRight className="w-4 h-4" /></>}
        </Button>
      </form>
    </Card>
  );
}

function SetupForm({ onDone }: { onDone: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);

  const strength = passwordStrength(password);

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (busy) return;
    if (!email.trim() || !password) { toast.error("Enter an email and password"); return; }
    if (password.length < 8) { toast.error("Password must be at least 8 characters"); return; }
    if (password !== confirm) { toast.error("Passwords don't match"); return; }
    setBusy(true);
    try {
      const res = await fetchApi("/api/auth/bootstrap", {
        method: "POST",
        body: { email: email.trim().toLowerCase(), password, name: name.trim() || undefined },
      });
      if (res.ok) {
        toast.success("Admin account created");
        onDone();
      } else {
        toast.error(res.error || "Setup failed");
      }
    } catch (e: any) {
      toast.error(e?.message || "Setup failed — please try again");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="p-7 bg-card/80 backdrop-blur-sm border-border/60 shadow-2xl shadow-black/20">
      <div className="flex items-start gap-3 mb-5 pb-5 border-b border-border/60">
        <Shield className="w-5 h-5 text-violet mt-0.5 flex-shrink-0" />
        <div>
          <h2 className="text-sm font-semibold">Create the admin account</h2>
          <p className="text-xs text-muted-foreground mt-1">
            This is a fresh install — set up the first administrator for this PrimePool instance.
          </p>
        </div>
      </div>
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-xs text-muted-foreground">Name (optional)</Label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Administrator" className="pl-9" />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="setup-email" className="text-xs text-muted-foreground">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input id="setup-email" type="email" autoFocus required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" className="pl-9" />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="setup-password" className="text-xs text-muted-foreground">Password</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              id="setup-password"
              type={show ? "text" : "password"}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="At least 8 characters"
              className="pl-9 pr-10"
            />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" tabIndex={-1}>
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {password && (
            <div className="flex gap-1 pt-1">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className={`h-1 flex-1 rounded-full ${i < strength.score ? strength.color : "bg-muted"}`} />
              ))}
            </div>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm-password" className="text-xs text-muted-foreground">Confirm password</Label>
          <Input
            id="confirm-password"
            type={show ? "text" : "password"}
            required
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            placeholder="••••••••"
          />
        </div>
        <Button type="submit" disabled={busy} className="w-full bg-violet hover:bg-violet/90 gap-1.5">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Create admin account <ArrowRight className="w-4 h-4" /></>}
        </Button>
      </form>
    </Card>
  );
}

function passwordStrength(pw: string): { score: number; color: string } {
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/[0-9]/.test(pw) && /[^A-Za-z0-9]/.test(pw)) score++;
  const colors = ["bg-danger", "bg-warning", "bg-info", "bg-success"];
  return { score, color: colors[Math.max(0, score - 1)] || "bg-danger" };
}

export function PrimePoolLogo({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="pp-grad" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="var(--violet)" />
          <stop offset="100%" stopColor="var(--cyan)" />
        </linearGradient>
      </defs>
      <line x1="20" y1="20" x2="8" y2="8" stroke="url(#pp-grad)" strokeWidth="1.5" opacity="0.6" />
      <line x1="20" y1="20" x2="32" y2="8" stroke="url(#pp-grad)" strokeWidth="1.5" opacity="0.6" />
      <line x1="20" y1="20" x2="8" y2="32" stroke="url(#pp-grad)" strokeWidth="1.5" opacity="0.6" />
      <line x1="20" y1="20" x2="32" y2="32" stroke="url(#pp-grad)" strokeWidth="1.5" opacity="0.6" />
      <circle cx="8" cy="8" r="3" fill="var(--cyan)" />
      <circle cx="32" cy="8" r="3" fill="var(--cyan)" />
      <circle cx="8" cy="32" r="3" fill="var(--cyan)" />
      <circle cx="32" cy="32" r="3" fill="var(--cyan)" />
      <circle cx="20" cy="20" r="7" fill="url(#pp-grad)" />
      <circle cx="20" cy="20" r="3" fill="white" opacity="0.7" />
    </svg>
  );
}

// Backward-compatible alias
export { PrimePoolLogo as DarkpoolLogo };
