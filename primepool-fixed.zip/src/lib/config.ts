// PRIMEPOOL config — single source of truth for tunables.
// Reads from environment with sensible defaults.

export const config = {
  // HTTP
  port: Number(process.env.PORT || 3000),
  publicUrl: process.env.PUBLIC_URL || "http://localhost:3000",

  // Auth
  jwtSecret: process.env.JWT_SECRET || "dev-only-secret-CHANGE-ME",
  sessionTtlMs: Number(process.env.SESSION_TTL_MS || 24 * 60 * 60 * 1000), // 24h
  bcryptRounds: Number(process.env.BCRYPT_ROUNDS || 10),

  // Heartbeat
  heartbeatIntervalMs: Number(process.env.HEARTBEAT_INTERVAL_MS || 10_000),
  heartbeatStaleMs: Number(process.env.HEARTBEAT_STALE_MS || 30_000), // after 30s → unstable
  heartbeatOfflineMs: Number(process.env.HEARTBEAT_OFFLINE_MS || 60_000), // after 60s → offline
  gracePeriodMs: Number(process.env.GRACE_PERIOD_MS || 5 * 60_000), // don't destroy workloads for 5m

  // Resource reserves — headroom kept aside so the host OS always has
  // something to breathe with. Defaults are tuned to support minimal
  // 1-core / 1GB supporter nodes (the minimum supported node spec).
  cpuReserveCores: Number(process.env.CPU_RESERVE ?? 0),
  ramReserveMb: Number(process.env.RAM_RESERVE_MB ?? 256),
  diskReserveGb: Number(process.env.DISK_RESERVE_GB ?? 1),

  // Minimum node spec PrimePool will accept as a worker. 1 core / 512MB RAM
  // is the practical floor — below this a node can't reliably run even the
  // lightest workload alongside its own OS.
  minNodeCpuCores: Number(process.env.MIN_NODE_CPU_CORES || 1),
  minNodeRamMb: Number(process.env.MIN_NODE_RAM_MB || 512),
  minNodeDiskMb: Number(process.env.MIN_NODE_DISK_MB || 1024),

  // Scheduler
  schedulerWeights: {
    cpu: Number(process.env.SCHED_WEIGHT_CPU || 1.0),
    ram: Number(process.env.SCHED_WEIGHT_RAM || 1.0),
    disk: Number(process.env.SCHED_WEIGHT_DISK || 0.5),
    load: Number(process.env.SCHED_WEIGHT_LOAD || 0.8),
    runningCount: Number(process.env.SCHED_WEIGHT_RUNNING || 0.3),
  },

  // Overcommit (DISABLED by default — per spec)
  overcommitEnabled: process.env.OVERCOMMIT_ENABLED === "true",

  // Metrics retention
  metricsRetentionHours: Number(process.env.METRICS_RETENTION_HOURS || 24),

  // Rate limiting
  rateLimit: {
    windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000),
    max: Number(process.env.RATE_LIMIT_MAX || 120),
  },
} as const;

export type Config = typeof config;
