// GET /api/public/pool
// Public endpoint (no auth) for primepool-info / primepool df / primepool free / primepool nproc
// commands running INSIDE workspaces. Returns the resource pool + the requesting workload's
// allocation (identified via X-PrimePool-Workspace header set by the agent).
//
// ALSO serves the compiled agent source when ?download=agent is passed.

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getPoolSnapshot } from "@/lib/resource-pool";
import { serializeForJson } from "@/lib/serialize";
import { readFileSync } from "node:fs";
import { join } from "node:path";

export async function GET(req: NextRequest) {
  // Agent source download (for install-agent.sh fallback)
  const url = new URL(req.url);
  if (url.searchParams.get("download") === "agent") {
    try {
      const src = readFileSync(join(process.cwd(), "public", "download", "agent", "agent.js"), "utf8");
      return new NextResponse(src, {
        headers: {
          "content-type": "application/javascript; charset=utf-8",
          "cache-control": "no-store",
        },
      });
    } catch (e: any) {
      return NextResponse.json({ error: e.message }, { status: 500 });
    }
  }

  const pool = await getPoolSnapshot();
  const workspaceId = req.headers.get("x-primepool-workspace") || process.env.PRIMEPOOL_WORKSPACE;
  let workspace: any = null;
  if (workspaceId) {
    const w = await db.workload.findUnique({
      where: { workloadId: workspaceId },
      include: { node: true },
    });
    if (w) {
      workspace = {
        workloadId: w.workloadId,
        nodeId: w.node?.nodeId ?? null,
        cpuLimit: w.cpuLimit,
        ramLimitMb: w.ramLimitMb,
        diskLimitMb: w.diskLimitMb,
        status: w.status,
      };
    }
  }
  return NextResponse.json(serializeForJson({ ok: true, pool, workspace }));
}
