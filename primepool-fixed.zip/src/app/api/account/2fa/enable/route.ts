// POST /api/account/2fa/enable — verify the setup code and turn 2FA on; returns one-time recovery codes
import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, hashPassword } from "@/lib/auth";
import { db } from "@/lib/db";
import { verifyTotp, generateRecoveryCodes } from "@/lib/totp";
import { recordEvent, recordAudit } from "@/lib/logger";

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const { code } = body || {};
  if (!code) return NextResponse.json({ error: "verification code required" }, { status: 400 });

  const dbUser = await db.user.findUnique({ where: { id: user.id } });
  if (!dbUser?.totpSecret) return NextResponse.json({ error: "call /setup first" }, { status: 400 });

  if (!verifyTotp(dbUser.totpSecret, String(code))) {
    return NextResponse.json({ error: "invalid code — check your authenticator app's time sync" }, { status: 400 });
  }

  const recoveryCodes = generateRecoveryCodes();
  // Store hashed recovery codes; show plaintext to the user exactly once.
  const hashed = await Promise.all(recoveryCodes.map((c) => hashPassword(c)));
  await db.user.update({
    where: { id: user.id },
    data: { totpEnabled: true, totpRecoveryCodes: JSON.stringify(hashed) },
  });

  await recordEvent({ type: "auth.2fa_enabled", message: `${user.email} enabled two-factor authentication`, severity: "info" });
  await recordAudit({
    userId: user.id, action: "account.2fa_enabled",
    ipAddress: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null,
    userAgent: req.headers.get("user-agent") ?? null,
  });

  return NextResponse.json({ ok: true, recoveryCodes });
}
