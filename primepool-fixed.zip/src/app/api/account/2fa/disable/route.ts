// POST /api/account/2fa/disable — turn off 2FA (requires current password)
import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, verifyPassword } from "@/lib/auth";
import { db } from "@/lib/db";
import { recordEvent, recordAudit } from "@/lib/logger";

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const { password } = body || {};
  if (!password) return NextResponse.json({ error: "current password required" }, { status: 400 });

  const dbUser = await db.user.findUnique({ where: { id: user.id } });
  if (!dbUser) return NextResponse.json({ error: "user not found" }, { status: 404 });
  const valid = await verifyPassword(password, dbUser.passwordHash);
  if (!valid) return NextResponse.json({ error: "incorrect password" }, { status: 401 });

  await db.user.update({
    where: { id: user.id },
    data: { totpEnabled: false, totpSecret: null, totpRecoveryCodes: null },
  });
  await recordEvent({ type: "auth.2fa_disabled", message: `${user.email} disabled two-factor authentication`, severity: "warning" });
  await recordAudit({
    userId: user.id, action: "account.2fa_disabled",
    ipAddress: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null,
    userAgent: req.headers.get("user-agent") ?? null,
  });

  return NextResponse.json({ ok: true });
}
