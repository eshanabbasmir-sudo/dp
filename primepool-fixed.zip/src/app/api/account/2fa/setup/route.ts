// POST /api/account/2fa/setup — generate a new TOTP secret for the current user (not yet enabled)
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { generateTotpSecret, totpKeyUri } from "@/lib/totp";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const secret = generateTotpSecret();
  // Store the pending secret but keep totpEnabled false until verified
  await db.user.update({ where: { id: user.id }, data: { totpSecret: secret, totpEnabled: false } });

  return NextResponse.json({
    ok: true,
    secret,
    otpauthUrl: totpKeyUri(secret, user.email),
  });
}
