// GET /api/account/2fa/status
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  const dbUser = await db.user.findUnique({ where: { id: user.id }, select: { totpEnabled: true, totpRecoveryCodes: true } });
  const recoveryCodesRemaining = dbUser?.totpRecoveryCodes ? JSON.parse(dbUser.totpRecoveryCodes).length : 0;
  return NextResponse.json({ ok: true, enabled: !!dbUser?.totpEnabled, recoveryCodesRemaining });
}
