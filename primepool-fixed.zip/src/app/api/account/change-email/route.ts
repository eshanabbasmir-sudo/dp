// POST /api/account/change-email
import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, changeUserEmail } from "@/lib/auth";
import { recordAudit } from "@/lib/logger";

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const { newEmail, password } = body;
  if (!newEmail || !password) {
    return NextResponse.json({ error: "missing newEmail or password" }, { status: 400 });
  }
  const oldEmail = user.email;
  const res = await changeUserEmail(user.id, newEmail, password);
  const ipAddress = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
  const userAgent = req.headers.get("user-agent") ?? null;
  if (!res.ok) {
    await recordAudit({ userId: user.id, action: "account.email_change_failed", ipAddress, userAgent, meta: { attemptedEmail: newEmail } });
    return NextResponse.json({ error: res.error }, { status: 400 });
  }
  await recordAudit({ userId: user.id, action: "account.email_changed", ipAddress, userAgent, meta: { from: oldEmail, to: newEmail.toLowerCase() } });
  return NextResponse.json({ ok: true });
}
