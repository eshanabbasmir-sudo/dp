// POST /api/auth/login
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, signSession, setSessionCookie, hashPassword } from "@/lib/auth";
import { config } from "@/lib/config";
import { recordEvent, recordAudit } from "@/lib/logger";
import { verifyTotp } from "@/lib/totp";

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes

// Bootstrap admin seeder — SECURITY: disabled by default.
// A hardcoded default admin that silently re-creates itself on every login
// attempt is a serious security hole in production (predictable credentials,
// no way to fully remove the account). This now only runs when explicitly
// opted into via env, is gated to when zero users exist, and requires a
// password to be supplied (never ships a built-in default password).
//
// Normal flow: the FIRST visit to the login page creates the bootstrap admin
// with a password the operator sets at that time (see /api/auth/bootstrap).
async function ensureDefaultAdmin() {
  if (process.env.ENABLE_DEFAULT_ADMIN !== "true") return;
  const email = process.env.DEFAULT_ADMIN_EMAIL;
  const password = process.env.DEFAULT_ADMIN_PASSWORD;
  if (!email || !password) {
    console.warn("ENABLE_DEFAULT_ADMIN=true but DEFAULT_ADMIN_EMAIL/DEFAULT_ADMIN_PASSWORD not set — skipping");
    return;
  }
  try {
    const userCount = await db.user.count();
    if (userCount > 0) return; // never recreate once any account exists
    const passwordHash = await hashPassword(password);
    await db.user.create({
      data: { email: email.toLowerCase(), name: "Administrator", passwordHash, role: "admin" },
    });
    await recordEvent({
      type: "auth.bootstrap",
      message: `default admin ${email} created from environment`,
      severity: "warning",
    });
  } catch (e) {
    console.warn("ensureDefaultAdmin failed:", e);
  }
}

export async function POST(req: NextRequest) {
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "invalid json" }, { status: 400 }); }
  const { email, password, totpCode: suppliedTotp } = body || {};
  if (!email || !password) return NextResponse.json({ error: "missing email or password" }, { status: 400 });

  // Ensure the default admin account always exists (idempotent)
  await ensureDefaultAdmin();

  const user = await db.user.findUnique({ where: { email: String(email).toLowerCase() } });
  if (!user) return NextResponse.json({ error: "invalid email or password" }, { status: 401 });
  if (user.status !== "active") return NextResponse.json({ error: "user disabled" }, { status: 403 });

  // Account lockout after repeated failures
  if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
    const minutesLeft = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
    return NextResponse.json({ error: `account temporarily locked — try again in ${minutesLeft} minute(s)` }, { status: 429 });
  }

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) {
    const attempts = (user.failedLoginAttempts || 0) + 1;
    const lockedUntil = attempts >= MAX_FAILED_ATTEMPTS ? new Date(Date.now() + LOCKOUT_MS) : null;
    await db.user.update({ where: { id: user.id }, data: { failedLoginAttempts: attempts, lockedUntil } });
    await recordEvent({ type: "auth.failure", message: `failed login for ${email}${lockedUntil ? " — account locked" : ""}`, severity: "warning" });
    await recordAudit({
      userId: user.id, action: "auth.failure",
      ipAddress: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null,
      userAgent: req.headers.get("user-agent") ?? null,
      meta: { attempts, locked: !!lockedUntil },
    });
    if (lockedUntil) {
      return NextResponse.json({ error: `too many failed attempts — account locked for ${LOCKOUT_MS / 60000} minutes` }, { status: 429 });
    }
    return NextResponse.json({ error: "invalid email or password" }, { status: 401 });
  }

  // Second factor, if enabled on this account
  if (user.totpEnabled && user.totpSecret) {
    if (!suppliedTotp) {
      return NextResponse.json({ ok: false, requiresTotp: true });
    }
    const codeOk = verifyTotp(user.totpSecret, String(suppliedTotp));
    let recoveryUsed = false;
    if (!codeOk) {
      // check recovery codes (stored as bcrypt hashes)
      const hashedCodes: string[] = user.totpRecoveryCodes ? JSON.parse(user.totpRecoveryCodes) : [];
      const candidate = String(suppliedTotp).trim();
      let matchIdx = -1;
      for (let i = 0; i < hashedCodes.length; i++) {
        if (await verifyPassword(candidate, hashedCodes[i])) { matchIdx = i; break; }
      }
      if (matchIdx === -1) {
        await recordEvent({ type: "auth.failure", message: `failed 2FA for ${email}`, severity: "warning" });
        return NextResponse.json({ error: "invalid authentication code" }, { status: 401 });
      }
      recoveryUsed = true;
      hashedCodes.splice(matchIdx, 1);
      await db.user.update({ where: { id: user.id }, data: { totpRecoveryCodes: JSON.stringify(hashedCodes) } });
      await recordEvent({ type: "auth.recovery_code_used", message: `${email} logged in using a 2FA recovery code (${hashedCodes.length} remaining)`, severity: "warning" });
    }
  }

  // Successful login — reset failure counter
  await db.user.update({ where: { id: user.id }, data: { failedLoginAttempts: 0, lockedUntil: null, lastLoginAt: new Date() } });

  const token = signSession({ userId: user.id, role: user.role });
  await setSessionCookie(token, config.sessionTtlMs);
  await db.session.create({
    data: {
      userId: user.id, token,
      expiresAt: new Date(Date.now() + config.sessionTtlMs),
      userAgent: req.headers.get("user-agent") ?? null,
      ipAddress: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null,
    },
  });
  await recordEvent({ type: "auth.login", message: `${email} logged in`, severity: "info" });
  await recordAudit({
    userId: user.id, action: "auth.login",
    ipAddress: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null,
    userAgent: req.headers.get("user-agent") ?? null,
  });
  return NextResponse.json({ ok: true, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
}
