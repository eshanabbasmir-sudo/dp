// GET  /api/auth/bootstrap — tells the login screen whether a first-run admin setup is needed
// POST /api/auth/bootstrap — creates the first admin account (ONLY works when zero users exist)
//
// SECURITY: this intentionally replaces any notion of a hardcoded default
// admin. It only ever succeeds once — the moment any user row exists in the
// database, this endpoint permanently refuses to create another account.
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, signSession, setSessionCookie } from "@/lib/auth";
import { config } from "@/lib/config";
import { recordEvent } from "@/lib/logger";

export async function GET() {
  const userCount = await db.user.count();
  return NextResponse.json({ ok: true, needsBootstrap: userCount === 0 });
}

export async function POST(req: NextRequest) {
  const userCount = await db.user.count();
  if (userCount > 0) {
    return NextResponse.json({ error: "setup already completed" }, { status: 403 });
  }
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "invalid json" }, { status: 400 }); }
  const { email, password, name } = body || {};
  if (!email || typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: "valid email required" }, { status: 400 });
  }
  if (!password || typeof password !== "string" || password.length < 8) {
    return NextResponse.json({ error: "password must be at least 8 characters" }, { status: 400 });
  }
  const passwordHash = await hashPassword(password);
  const user = await db.user.create({
    data: {
      email: email.toLowerCase(),
      name: name || "Administrator",
      passwordHash,
      role: "admin",
      lastPasswordChangeAt: new Date(),
    },
  });
  await recordEvent({
    type: "auth.bootstrap",
    message: `first admin account created: ${user.email}`,
    severity: "info",
  });
  const token = signSession({ userId: user.id, role: user.role });
  await setSessionCookie(token, config.sessionTtlMs);
  await db.session.create({
    data: {
      userId: user.id, token,
      expiresAt: new Date(Date.now() + config.sessionTtlMs),
      userAgent: req.headers.get("user-agent") ?? null,
      ipAddress: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null,
    },
  });
  return NextResponse.json({ ok: true, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
}
