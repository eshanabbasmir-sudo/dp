# PRIMEPOOL — Installation Guide

## Prerequisites

- **Main VPS**: Ubuntu 22.04+, 2 vCPU, 4 GB RAM, 20 GB disk, public IP, domain (for TLS)
- **Supporter VPS**: Ubuntu 22.04+, 1 vCPU, 1 GB RAM, 10 GB disk, can reach Main URL
- **Docker** (optional but recommended) on Supporter VPSs for full container isolation

## Install Main VPS

### Option A (recommended): `install.sh`

This is the simplest path — it installs every required system package, asks
which port to host on, and starts the app for you in one go. No separate
database, reverse proxy, or domain setup required to get running.

```bash
git clone <your-repo-url> primepool
cd primepool
bash install.sh
```

You'll be prompted for a port (default `3000`). The script then:
1. Installs Node.js 20 LTS and any missing build tools for your OS (apt/dnf/yum/pacman/apk all supported)
2. Installs project dependencies
3. Generates `.env` with a secure random `JWT_SECRET` and your chosen `PORT`
4. Sets up the SQLite database (`prisma db push` — no manual migration steps)
5. Builds the production app
6. Starts it — as a systemd service `primepool` when run as root, otherwise as a
   self-restarting background process — and prints the URL to open

Visit the printed URL — the first visit walks you through creating your admin
account. There's no default password.

To put PrimePool behind a domain with TLS afterwards, put Caddy or nginx in
front of it as a reverse proxy to `localhost:<your-port>` (see Option B below
for an example Caddy config), or set `PRIMEPOOL_DOMAIN` using the legacy
script described next.

### Option B: Legacy one-command install (systemd + Postgres + Caddy)

```bash
export PRIMEPOOL_REPO=https://github.com/your-org/primepool.git
export PRIMEPOOL_DOMAIN=primepool.example.com
export PRIMEPOOL_USE_POSTGRES=1
export PRIMEPOOL_PG_PASSWORD=<strong-password>

curl -fsSL https://raw.githubusercontent.com/your-org/primepool/main/public/scripts/install-main.sh | bash
```

The script:
1. Installs Node.js 20 LTS, Bun, PostgreSQL, Caddy
2. Creates a `primepool` service user
3. Clones the repo to `/opt/primepool`
4. Installs npm dependencies
5. Writes `.env` from `.env.example` (auto-generates `JWT_SECRET`)
6. Runs `prisma db push`
7. Builds Next.js
8. Installs a systemd unit `primepool.service`
9. Configures Caddy for TLS on your domain

After install:
```bash
sudo systemctl start primepool
# Visit https://your-domain — first login creates the bootstrap admin
```

### Option C: Manual dev install

```bash
git clone https://github.com/your-org/primepool.git
cd primepool
bun install
cp .env.example .env
# Edit .env — at minimum set JWT_SECRET
bun run db:push
bun run dev   # → http://localhost:3000
```

## Install Supporter VPS (worker agent)

### Step 1: Issue a registration token (on Main)

From the dashboard: **Workers → Add Worker → Issue Token**

Or via CLI (run on Main):
```bash
primepool token issue --label "worker-prod-01"
```

This returns a one-time token (24h expiry).

### Step 2: Run the installer on the Supporter VPS

```bash
export MAIN_URL=https://primepool.example.com
export REGISTRATION_TOKEN=<token-from-step-1>

curl -fsSL https://primepool.example.com/install-agent.sh | bash
```

The script:
1. Installs Node.js 20 LTS
2. Installs Docker (if not present)
3. Creates a `primepool-agent` service user, adds to `docker` group
4. Downloads the agent package from Main
5. Writes `/etc/primepool-agent.env` with credentials
6. Installs systemd unit `primepool-agent.service`
7. Starts the agent — it registers automatically with Main

### Verify

```bash
# On Supporter VPS:
systemctl status primepool-agent
journalctl -u primepool-agent -f

# On Main dashboard:
# Workers tab — your new worker should appear as ONLINE within ~10s
```

## CLI configuration

Install the admin CLI on your workstation:

```bash
# From a checkout:
cd cli && bun build && npm link

# Or copy dist/cli.js to /usr/local/bin/primepool

primepool login   # interactive: prompts for URL, email, password
```

After `primepool login`, credentials are stored in `~/.primepool/credentials.json` (mode 0600).

## Verify the install

End-to-end acceptance test:

```bash
# 1. List workers (should show your new worker)
primepool node list

# 2. Show pool resources
primepool resources

# 3. Create a workload
primepool workload create --name test --cpu 1 --ram 512 --disk 1024

# 4. List workloads (should show RUNNING after ~5s)
primepool workloads

# 5. Open terminal in dashboard → run inside workload:
hostname        # → random container ID
uname -a        # → real kernel of the worker
nproc           # → CPU limit enforced by Docker (--cpus)
primepool-info   # → cluster overview from inside the workspace
primepool df     # → virtual pool storage view

# 6. Stop the workload
primepool workload stop ws-XXXX
```

## Troubleshooting

### Agent doesn't register

- Check `MAIN_URL` is reachable from the Supporter VPS (`curl $MAIN_URL/api/system/status`)
- Check `REGISTRATION_TOKEN` is valid (not expired, not used) — issue a new one if needed
- Check agent logs: `journalctl -u primepool-agent -n 100`

### Worker shows OFFLINE in dashboard

- Agent process down: `systemctl restart primepool-agent`
- Network issue between worker and Main: `ping` Main, check firewall
- Main unreachable: check Main is up (`systemctl status primepool`)

### Workload stuck in "scheduling"

- Agent not polling: check agent logs
- No suitable node: run `primepool resources` — is there available capacity?
- Insufficient reserves: check `CPU_RESERVE`, `RAM_RESERVE_MB`, `DISK_RESERVE_GB` in `.env`

### Workload "failed"

- Check the agent logs — Docker error?
- Image pull failed: try `docker pull ubuntu:22.04` manually on the worker
- Cap-drop too restrictive for your image: edit agent's `startWorkload` function

## Upgrading

### Main VPS

```bash
cd /opt/primepool
git pull
bun install
bun run db:push
bun run build
sudo systemctl restart primepool
```

### Supporter VPS

Re-run the install script — it will re-download the latest agent package and restart the service.
