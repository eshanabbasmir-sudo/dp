#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

npx tsc -p worker-agent/tsconfig.json
AGENT_JS="$ROOT/worker-agent/dist/agent.js"
for target in "$ROOT/public/scripts/agent.js" "$ROOT/public/download/agent/agent.js"; do
  install -D -m 0644 "$AGENT_JS" "$target"
done

cp "$ROOT/worker-agent/package.json" "$ROOT/public/scripts/agent-package.json"
cp "$ROOT/worker-agent/package.json" "$ROOT/public/download/agent/package.json"

PACKAGE_DIR="$(mktemp -d)"
trap 'rm -rf "$PACKAGE_DIR"' EXIT
mkdir -p "$PACKAGE_DIR/src"
cp "$AGENT_JS" "$PACKAGE_DIR/src/agent.js"
cp "$ROOT/worker-agent/package.json" "$PACKAGE_DIR/package.json"
tar -czf "$ROOT/public/download/agent/primepool-agent.tar.gz" -C "$PACKAGE_DIR" package.json src/agent.js

echo "Compiled worker agent and refreshed public download artifacts."
