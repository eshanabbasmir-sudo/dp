#!/usr/bin/env bash
# PRIMEPOOL Supporter VPS installer. Downloads the compiled ESM worker agent.
# Usage: curl -fsSL https://<main>/scripts/install-agent.sh | MAIN_URL=... REGISTRATION_TOKEN=... bash
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[primepool]${NC} $*"; }
warn() { echo -e "${YELLOW}[warn]${NC} $*"; }
err()  { echo -e "${RED}[error]${NC} $*" >&2; }

MAIN_URL="${MAIN_URL:-}"
REGISTRATION_TOKEN="${REGISTRATION_TOKEN:-}"
if [[ -z "$MAIN_URL" ]]; then err "MAIN_URL env var required"; exit 1; fi
if [[ -z "$REGISTRATION_TOKEN" ]]; then err "REGISTRATION_TOKEN env var required"; exit 1; fi
MAIN_URL="${MAIN_URL%/}"

if ! command -v node >/dev/null 2>&1; then
  err "Node.js 20+ is required. Install Node.js, then re-run this command."
  exit 1
fi
NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if (( NODE_MAJOR < 20 )); then err "Node.js 20+ is required (found $(node -v))."; exit 1; fi

if [[ "$EUID" -eq 0 ]]; then
  INSTALL_DIR="${AGENT_DIR:-/opt/primepool-agent}"
else
  INSTALL_DIR="${AGENT_DIR:-$HOME/primepool-agent}"
fi
mkdir -p "$INSTALL_DIR/data"
chmod 700 "$INSTALL_DIR"

log "Downloading compiled PRIMEPOOL worker agent from $MAIN_URL"
curl -fsSL "$MAIN_URL/download/agent/agent.js" -o "$INSTALL_DIR/agent.mjs"
chmod 755 "$INSTALL_DIR/agent.mjs"

ENV_FILE="$INSTALL_DIR/.env"
cat > "$ENV_FILE" <<EOF
MAIN_URL=$MAIN_URL
REGISTRATION_TOKEN=$REGISTRATION_TOKEN
HEARTBEAT_INTERVAL=${HEARTBEAT_INTERVAL:-10000}
POLL_INTERVAL=${POLL_INTERVAL:-5000}
AGENT_DATA_DIR=$INSTALL_DIR/data
PRIMEPOOL_AGENT_CONFIG=$INSTALL_DIR/agent.json
EOF
chmod 600 "$ENV_FILE"

if [[ "$EUID" -eq 0 ]] && command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  cat > /etc/systemd/system/primepool-agent.service <<EOF
[Unit]
Description=PRIMEPOOL Worker Agent
After=network.target

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$(command -v node) $INSTALL_DIR/agent.mjs
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable primepool-agent >/dev/null
  systemctl restart primepool-agent
  sleep 2
  if systemctl is-active --quiet primepool-agent; then
    log "Agent is running as systemd service primepool-agent."
    log "Logs: journalctl -u primepool-agent -f"
  else
    err "Agent failed to start. Recent logs:"
    journalctl -u primepool-agent --no-pager -n 30
    exit 1
  fi
else
  WATCHDOG="$INSTALL_DIR/agent-watchdog.sh"
  LOG_FILE="$INSTALL_DIR/agent.log"
  PID_FILE="$INSTALL_DIR/agent.pid"
  cat > "$WATCHDOG" <<EOF
#!/usr/bin/env bash
cd "$INSTALL_DIR"
while true; do
  set -a; source "$ENV_FILE"; set +a
  "$(command -v node)" "$INSTALL_DIR/agent.mjs" >> "$LOG_FILE" 2>&1
  echo "[watchdog] agent exited; restarting in 5s" >> "$LOG_FILE"
  sleep 5
done
EOF
  chmod 700 "$WATCHDOG"
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    sleep 1
  fi
  nohup "$WATCHDOG" >/dev/null 2>&1 &
  echo $! > "$PID_FILE"
  sleep 2
  if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    log "Agent is running under the rootless watchdog (PID $(cat "$PID_FILE"))."
    log "Logs: tail -f $LOG_FILE"
  else
    err "Agent did not remain running. Recent logs:"
    tail -n 30 "$LOG_FILE" 2>/dev/null || true
    exit 1
  fi
fi
